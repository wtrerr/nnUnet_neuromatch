CREATE TABLE IF NOT EXISTS grch38_ground_level_versions (
    accession TEXT NOT NULL,
    biosample TEXT NOT NULL,
    assay TEXT NOT NULL,
    version TEXT NOT NULL
);