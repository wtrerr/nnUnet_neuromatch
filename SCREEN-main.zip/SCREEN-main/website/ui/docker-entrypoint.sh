#!/bin/bash

yarn
yarn start
