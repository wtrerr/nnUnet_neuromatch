import React from "react"

const DataMatrixPage: React.FC = () => {
  return null
}
export default DataMatrixPage
