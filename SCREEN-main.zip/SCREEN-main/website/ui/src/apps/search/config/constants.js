/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2016-2020 Michael Purcaro, Henry Pratt, Jill Moore, Zhiping Weng
 */

export const default_margin = {
  top: 1,
  bottom: 1,
  left: 1,
  right: 1,
}
